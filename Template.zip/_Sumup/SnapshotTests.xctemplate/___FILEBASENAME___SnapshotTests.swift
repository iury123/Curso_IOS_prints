//___FILEHEADER___

//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.

@testable import BrBankServicesKit

class ___VARIABLE_productName:identifier___SnapshotTests: BaseSnapshotTests {

    override func setUp() {
        super.setUp()
        recordMode = false
    }

    func testSnapshots_ptBR() {
        String.localizationTestLang = "pt"
    }

    func testSnapshots_enUS() {
        String.localizationTestLang = "en"
    }
}
