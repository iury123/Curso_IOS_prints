//___FILEHEADER___

//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.

import Foundation

// MARK: ===== Configurator =====
public struct ___VARIABLE_productName:identifier___Configurator {

    public init() {}

    public func configure(with dependencies: BrBankServicesDependencies) -> UIViewController {
        let view = ___VARIABLE_productName:identifier___Controller()
        let presenter = ___VARIABLE_productName:identifier___Presenter(with: view, servicesFeatureFlags: dependencies.featureFlags)
        let networkingWorker = dependencies.networking
        let router = ___VARIABLE_productName:identifier___Router(dependencies: dependencies, source: view)
        view.interactor = ___VARIABLE_productName:identifier___Interactor(with: presenter, networkingWorker: networkingWorker, analyticsWorker: dependencies.analytics)
        view.router = router

        return view
    }
}
