//___FILEHEADER___

//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.

import CircuitUI
import UIKit

// MARK: ===== View =====
protocol ___VARIABLE_productName:identifier___DisplayLogic: AnyObject {
    var interactor: ___VARIABLE_productName:identifier___BusinessLogic? { get set }
    var router: ___VARIABLE_productName:identifier___Router? { get set }
    var tableView: UITableView { get set }
    var tableViewContent: [String] { get set }
}

protocol ___VARIABLE_productName:identifier___DisplayOutput: AnyObject {
    func reloadContent(with: [String])
}

public protocol ___VARIABLE_productName:identifier___DisplayInput: AnyObject {

}

// MARK: ===== Display Logic =====
final class ___VARIABLE_productName:identifier___Controller: UIViewController, ___VARIABLE_productName:identifier___DisplayLogic {

    var interactor: ___VARIABLE_productName:identifier___BusinessLogic?
    var router: ___VARIABLE_productName:identifier___Router?
    var tableViewContent = [String]() {
        didSet {
            tableView.reloadData()
        }
    }

    lazy var tableView: UITableView = {
        let view = UITableView()
        view.dataSource = self
        view.delegate = self
        view.backgroundColor = SemanticColor.background
        view.isScrollEnabled = false
        return view
    }()

    var isRootViewController: Bool { navigationController?.viewControllers.first == self }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = SemanticColor.background
        title = "Scene Title"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: " ", style: .plain, target: nil, action: nil)
        initSubviews()
        interactor?.loadViewContent()
        if isRootViewController { addCloseButton() }
    }

    private func initSubviews() {
        view.addSubview(tableView, with: [
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }

    private func addCloseButton() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "close",
                                                           style: .done,
                                                           target: self,
                                                           action: #selector(close))
    }

    @objc private func close() {
        if isRootViewController {
            dismiss(animated: true)
        } else {
            navigationController?.popViewController(animated: true)
        }
    }
}

// MARK: ===== Display Output =====
// (Output represents all things that should be shown to user)
extension ___VARIABLE_productName:identifier___Controller: ___VARIABLE_productName:identifier___DisplayOutput {
    func reloadContent(with content: [String]) {
        tableViewContent = content
    }
}

// MARK: ===== Display Input =====
// (Input represents all user actions on scene)
extension ___VARIABLE_productName:identifier___Controller: ___VARIABLE_productName:identifier___DisplayInput {

}

// MARK: ===== Table View Data Source =====
extension ___VARIABLE_productName:identifier___Controller: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tableViewContent.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let actionItemConfig = ___VARIABLE_productName:identifier___ViewModel().contentCellWith(value: tableViewContent[indexPath.row])
            tableView.register(navigationCellConfigs: [actionItemConfig])

            // dequeue a cell before display
            let actionCell = tableView.dequeueReusableCell(configuration: actionItemConfig, indexPath: indexPath)
            actionCell.applyConfiguration(actionItemConfig)
            return actionCell
    }
}

// MARK: ===== Table View Data Delegate =====
extension ___VARIABLE_productName:identifier___Controller: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("One Row Selected")
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
