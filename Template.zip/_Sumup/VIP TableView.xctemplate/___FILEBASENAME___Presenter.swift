//___FILEHEADER___

//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.

import Foundation

// MARK: ===== Presenter =====
protocol ___VARIABLE_productName:identifier___PresentationLogic: AnyObject {
    var view: ___VARIABLE_productName:identifier___DisplayOutput? { get }
    var servicesFeatureFlags: BrBankServicesFeatureFlags? { get }

    init (with view: ___VARIABLE_productName:identifier___DisplayOutput, servicesFeatureFlags: BrBankServicesFeatureFlags?)

    func loadViewContent(with content: [ContentCellType])

}

final class ___VARIABLE_productName:identifier___Presenter: ___VARIABLE_productName:identifier___PresentationLogic {
    weak var view: ___VARIABLE_productName:identifier___DisplayOutput?
    var servicesFeatureFlags: BrBankServicesFeatureFlags?

    required init(with view: ___VARIABLE_productName:identifier___DisplayOutput, servicesFeatureFlags: BrBankServicesFeatureFlags? = nil) {
        self.view = view
        self.servicesFeatureFlags = servicesFeatureFlags
    }

    func loadViewContent(with content: [ContentCellType]) {
        view?.reloadContent(with: HomeViewModel().buildViewContent(with: content))
    }
}
