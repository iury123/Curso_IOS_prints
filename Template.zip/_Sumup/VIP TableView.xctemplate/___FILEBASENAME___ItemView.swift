//___FILEHEADER___

//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.

import CircuitUI
import UIKit

enum ContentCellType {
    case defaultContent
}

class GenericTableViewCell: UITableViewCell {

    override var reuseIdentifier: String? { "GenericTableViewCell" }

    lazy var containerView = UIView()

    func setupViews() {
        contentView.addSubview(containerView, with: [
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
        ])
    }

    func setUpCell(with view: UIView) {
        self.containerView = view
    }
}

struct ___VARIABLE_productName:identifier___ViewModel {

    func buildViewContent(with content: [ContentCellType]) -> [String] {
        var formatedContent = [String]()
        content.forEach { item in
            switch item {
            case .defaultContent:
                formatedContent.append("item")
            }
        }
        return formatedContent
    }

    func contentCellWith(value: String) -> ListContentConfigurationNavigation {
        let image = UIImage.safeNamedSharedImage("interest_on_balance_24") ?? UIImage()
        let actionItemConfig = ListContentConfigurationNavigation.singleLine(
            leadingElement: .image(image, contentMode: .scaleAspectFit),
            leadingText: value)
        return actionItemConfig
    }
}
