//___FILEHEADER___

//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.

import Foundation

protocol ___VARIABLE_productName:identifier___RoutingLogic {
    var source: UIViewController? { get }

    init(dependencies: BrBankServicesDependencies, source: UIViewController?)
}

final class ___VARIABLE_productName:identifier___Router: ___VARIABLE_productName:identifier___RoutingLogic {
    weak var source: UIViewController?
    let dependencies: BrBankServicesDependencies

    init(dependencies: BrBankServicesDependencies, source: UIViewController? = nil) {
        self.dependencies = dependencies
        self.source = source
    }
}

extension ___VARIABLE_productName:identifier___Router {
	//Put here the navigation push
}
