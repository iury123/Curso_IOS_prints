//___FILEHEADER___

// MARK: ===== Presenter =====
protocol ___VARIABLE_productName:identifier___PresentationLogic {
    var view: ___VARIABLE_productName:identifier___DisplayOutput? { get set }

    init(viewModel: ___VARIABLE_productName:identifier___ViewModelProtocol,
         servicesFeatureFlags: BrBankServicesFeatureFlagsWorker?)
    func loadViewContent()
    func showError()
}

final class ___VARIABLE_productName:identifier___Presenter: ___VARIABLE_productName:identifier___PresentationLogic {
    weak var view: ___VARIABLE_productName:identifier___DisplayOutput?
    private let viewModel: ___VARIABLE_productName:identifier___ViewModelProtocol
    private let servicesFeatureFlags: BrBankServicesFeatureFlagsWorker?

    required init(viewModel: ___VARIABLE_productName:identifier___ViewModelProtocol,
                  servicesFeatureFlags: BrBankServicesFeatureFlagsWorker? = nil) {
        self.viewModel = viewModel
        self.servicesFeatureFlags = servicesFeatureFlags
    }

    func loadViewContent() {
    }

    func showError() {
        view?.isShowLoading = false
        view?.showError()
    }
}
