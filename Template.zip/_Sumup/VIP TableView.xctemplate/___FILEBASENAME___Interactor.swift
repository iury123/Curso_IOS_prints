//___FILEHEADER___

//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.

import Foundation

// MARK: ===== Interactor =====
protocol ___VARIABLE_productName:identifier___BusinessLogic: AnyObject {
    var presenter: ___VARIABLE_productName:identifier___PresentationLogic? { get }
    var analyticsWorker: BrBankServicesAnalyticsLogic? { get }
    var networkingWorker: BrBankServicesNetworkingLogic { get }

    init(with presenter: ___VARIABLE_productName:identifier___PresentationLogic,
         networkingWorker: BrBankServicesNetworkingLogic,
         analyticsWorker: BrBankServicesAnalyticsLogic?)

    func loadViewContent()
}

final class ___VARIABLE_productName:identifier___Interactor: ___VARIABLE_productName:identifier___BusinessLogic {

    var presenter: ___VARIABLE_productName:identifier___PresentationLogic?
    let analyticsWorker: BrBankServicesAnalyticsLogic?
    let networkingWorker: BrBankServicesNetworkingLogic

    required init (with presenter: ___VARIABLE_productName:identifier___PresentationLogic,
                   networkingWorker: BrBankServicesNetworkingLogic,
                   analyticsWorker: BrBankServicesAnalyticsLogic? = nil) {
        self.presenter = presenter
        self.analyticsWorker = analyticsWorker
        self.networkingWorker = networkingWorker
    }

    func loadViewContent() {
        var viewContent = [ContentCellType]()
        viewContent.append(.defaultContent)
        presenter?.loadViewContent(with: viewContent)
    }
}
