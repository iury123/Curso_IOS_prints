//___FILEHEADER___

// MARK: ===== Configurator =====
public struct ___VARIABLE_productName:identifier___Configurator {
    public init() {}

    public func configure(with dependencies: BrBankServicesDependencies) -> UIViewController {
        let viewModel = ___VARIABLE_productName:identifier___ViewModel()
        let router = ___VARIABLE_productName:identifier___Router(dependencies: dependencies)
        let presenter = ___VARIABLE_productName:identifier___Presenter(viewModel: viewModel, servicesFeatureFlags: dependencies.featureFlags)
        let interactor = ___VARIABLE_productName:identifier___Interactor(with: presenter, analyticsWorker: dependencies.analytics)
        let view = ___VARIABLE_productName:identifier___View(interactor: interactor, router: router)
        router.source = view
        presenter.view = view
        return view
    }
}
