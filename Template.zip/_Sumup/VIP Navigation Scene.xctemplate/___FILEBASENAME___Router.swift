//___FILEHEADER___

enum ___VARIABLE_productName:identifier___SceneId: Int {
    case undefined
}

protocol ___VARIABLE_productName:identifier___RoutingLogic {
    var source: UIViewController? { get set }

    init(dependencies: BrBankServicesDependencies)
    func openScene()
}

final class ___VARIABLE_productName:identifier___Router: ___VARIABLE_productName:identifier___RoutingLogic {
    weak var source: UIViewController?
    private let dependencies: BrBankServicesDependencies

    init(dependencies: BrBankServicesDependencies) {
        self.dependencies = dependencies
    }

    func openScene() {
        //This is where you open the next scene
    }
}
