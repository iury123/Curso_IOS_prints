//___FILEHEADER___

// MARK: ===== Display Output =====
protocol ___VARIABLE_productName:identifier___DisplayOutput: AnyObject {
    var isShowLoading: Bool { get set }

    func showError()
}

// MARK: ===== Display Logic =====
final class ___VARIABLE_productName:identifier___View: BrBankServicesBaseViewController {
    var isShowLoading = true {
        didSet {
            isShowLoading ? startLoading() : finishLoading()
        }
    }
    private let interactor: ___VARIABLE_productName:identifier___BusinessLogic
    private let router: ___VARIABLE_productName:identifier___RoutingLogic

    init(interactor: ___VARIABLE_productName:identifier___BusinessLogic,
         router: ___VARIABLE_productName:identifier___RoutingLogic) {
        self.interactor = interactor
        self.router = router
        super.init()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Scene Title".sharedLocalizedString()
        interactor.loadViewContent()
    }
}

extension ___VARIABLE_productName:identifier___View: ___VARIABLE_productName:identifier___DisplayOutput {
    func showError() {
        showFullScreenError()
    }
}
