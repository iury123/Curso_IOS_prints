//___FILEHEADER___

// MARK: ===== Interactor =====
protocol ___VARIABLE_productName:identifier___BusinessLogic {
    init(with presenter: ___VARIABLE_productName:identifier___PresentationLogic,
         analyticsWorker: BrBankServicesAnalyticsWorker?)
    func loadViewContent()
}

final class ___VARIABLE_productName:identifier___Interactor: ___VARIABLE_productName:identifier___BusinessLogic {
    private let presenter: ___VARIABLE_productName:identifier___PresentationLogic
    private let analyticsWorker: BrBankServicesAnalyticsWorker?

    required init(with presenter: ___VARIABLE_productName:identifier___PresentationLogic,
                  analyticsWorker: BrBankServicesAnalyticsWorker? = nil) {
        self.presenter = presenter
        self.analyticsWorker = analyticsWorker
    }

    func loadViewContent() {
        presenter.loadViewContent()
    }
}
